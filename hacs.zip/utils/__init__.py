"""Initialize HACS utils."""
